package br.com.ado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssistenteOrganizacaoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AssistenteOrganizacaoApplication.class, args);
    }
}
