package br.com.ado.dto;

import br.com.ado.model.Prioridade;
import br.com.ado.model.Tarefa;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

/** Dados do formulário de criar/editar tarefa (com validação). */
public class TarefaForm {

    @NotBlank(message = "Informe o título da tarefa.")
    @Size(max = 100, message = "O título deve ter no máximo 100 caracteres.")
    private String titulo;

    @NotNull(message = "Informe a data da tarefa.")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate data;

    @NotNull(message = "Informe a prioridade.")
    private Prioridade prioridade = Prioridade.MEDIA;

    public static TarefaForm de(Tarefa tarefa) {
        TarefaForm form = new TarefaForm();
        form.titulo = tarefa.getTitulo();
        form.data = tarefa.getData();
        form.prioridade = tarefa.getPrioridade();
        return form;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public Prioridade getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(Prioridade prioridade) {
        this.prioridade = prioridade;
    }
}
