package br.com.ado.model;

/**
 * Equivalente ao PRIORIDADES do models.py. Concentra também o texto, o ícone
 * e a classe CSS usados na tela, para o template não precisar de if/elif.
 */
public enum Prioridade {

    ALTA("Alta", "🔴", "alta"),
    MEDIA("Média", "🟡", "media"),
    BAIXA("Baixa", "🟢", "baixa");

    private final String rotulo;
    private final String icone;
    private final String css;

    Prioridade(String rotulo, String icone, String css) {
        this.rotulo = rotulo;
        this.icone = icone;
        this.css = css;
    }

    public String getRotulo() {
        return rotulo;
    }

    public String getIcone() {
        return icone;
    }

    public String getCss() {
        return css;
    }
}
