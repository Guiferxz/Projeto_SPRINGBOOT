package br.com.ado.controller;

import br.com.ado.dto.TarefaForm;
import br.com.ado.model.Prioridade;
import br.com.ado.model.Tarefa;
import br.com.ado.service.TarefaService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TarefaController {

    private static final String VIEW_LISTA = "tarefas/lista";
    private static final String VIEW_EDITAR = "tarefas/editar";
    private static final String REDIRECT_LISTA = "redirect:/";

    private final TarefaService service;

    public TarefaController(TarefaService service) {
        this.service = service;
    }

    /** Disponibiliza as prioridades (para os <select>) em todas as telas. */
    @ModelAttribute("prioridades")
    public Prioridade[] prioridades() {
        return Prioridade.values();
    }

    // ---------- Lista + criação (rota "/") ----------

    @GetMapping("/")
    public String lista(@RequestParam(name = "filtro", defaultValue = "") String filtro,
                        @RequestParam(name = "pesquisa", defaultValue = "") String pesquisa,
                        Model model) {
        if (!model.containsAttribute("tarefaForm")) {
            model.addAttribute("tarefaForm", new TarefaForm());
        }
        preencherLista(model, filtro, pesquisa);
        return VIEW_LISTA;
    }

    @PostMapping("/")
    public String criar(@Valid @ModelAttribute("tarefaForm") TarefaForm form,
                        BindingResult result,
                        Model model) {
        if (result.hasErrors()) {
            preencherLista(model, "", "");
            return VIEW_LISTA;
        }
        service.criar(form);
        return REDIRECT_LISTA;
    }

    // ---------- Concluir / excluir ----------

    @PostMapping("/concluir/{id}")
    public String concluir(@PathVariable("id") Long id) {
        service.alternarConclusao(id);
        return REDIRECT_LISTA;
    }

    @PostMapping("/deletar/{id}")
    public String deletar(@PathVariable("id") Long id) {
        service.excluir(id);
        return REDIRECT_LISTA;
    }

    // ---------- Editar ----------

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable("id") Long id, Model model) {
        Tarefa tarefa = service.buscarPorId(id);
        model.addAttribute("tarefaForm", TarefaForm.de(tarefa));
        model.addAttribute("tarefaId", id);
        return VIEW_EDITAR;
    }

    @PostMapping("/editar/{id}")
    public String atualizar(@PathVariable("id") Long id,
                            @Valid @ModelAttribute("tarefaForm") TarefaForm form,
                            BindingResult result,
                            Model model) {
        if (result.hasErrors()) {
            service.buscarPorId(id); // garante 404 se a tarefa não existir
            model.addAttribute("tarefaId", id);
            return VIEW_EDITAR;
        }
        service.atualizar(id, form);
        return REDIRECT_LISTA;
    }

    private void preencherLista(Model model, String filtro, String pesquisa) {
        model.addAttribute("tarefas", service.listar(filtro, pesquisa));
        model.addAttribute("resumo", service.resumo());
        model.addAttribute("filtro", filtro);
        model.addAttribute("pesquisa", pesquisa);
    }
}
