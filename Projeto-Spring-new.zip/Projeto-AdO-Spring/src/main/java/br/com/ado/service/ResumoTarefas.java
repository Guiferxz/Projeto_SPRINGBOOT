package br.com.ado.service;

/** Números do painel (Total, Hoje, Concluídas, Pendentes). */
public record ResumoTarefas(long total, long hoje, long concluidas, long pendentes) {
}
