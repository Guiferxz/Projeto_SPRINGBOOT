package br.com.ado.service;

import br.com.ado.dto.TarefaForm;
import br.com.ado.exception.TarefaNaoEncontradaException;
import br.com.ado.model.Tarefa;
import br.com.ado.repository.TarefaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Service
@Transactional(readOnly = true)
public class TarefaService {

    /** Mesmo fuso do TIME_ZONE do settings.py. */
    private static final ZoneId FUSO = ZoneId.of("America/Sao_Paulo");

    private static final Set<String> FILTROS = Set.of("concluidas", "pendentes", "alta");

    private final TarefaRepository repository;

    public TarefaService(TarefaRepository repository) {
        this.repository = repository;
    }

    public List<Tarefa> listar(String filtro, String pesquisa) {
        String filtroNormalizado = FILTROS.contains(filtro) ? filtro : "todas";
        String termo = pesquisa == null ? "" : pesquisa.trim();
        return repository.buscar(filtroNormalizado, montarPadraoLike(termo));
    }

    public ResumoTarefas resumo() {
        return new ResumoTarefas(
                repository.count(),
                repository.countByData(LocalDate.now(FUSO)),
                repository.countByConcluida(true),
                repository.countByConcluida(false));
    }

    public Tarefa buscarPorId(Long id) {
        return repository.findById(id).orElseThrow(() -> new TarefaNaoEncontradaException(id));
    }

    @Transactional
    public Tarefa criar(TarefaForm form) {
        Tarefa tarefa = new Tarefa();
        copiar(form, tarefa);
        return repository.save(tarefa);
    }

    @Transactional
    public Tarefa atualizar(Long id, TarefaForm form) {
        Tarefa tarefa = buscarPorId(id);
        copiar(form, tarefa);
        return repository.save(tarefa);
    }

    @Transactional
    public void alternarConclusao(Long id) {
        Tarefa tarefa = buscarPorId(id);
        tarefa.setConcluida(!tarefa.isConcluida());
        repository.save(tarefa);
    }

    @Transactional
    public void excluir(Long id) {
        repository.delete(buscarPorId(id));
    }

    private void copiar(TarefaForm form, Tarefa tarefa) {
        tarefa.setTitulo(form.getTitulo().trim());
        tarefa.setData(form.getData());
        tarefa.setPrioridade(form.getPrioridade());
    }

    /** Monta "%termo%" em minúsculas, tratando %, _ e ! digitados pelo usuário como texto literal. */
    private static String montarPadraoLike(String termo) {
        String escapado = termo.toLowerCase(Locale.ROOT)
                .replace("!", "!!")
                .replace("%", "!%")
                .replace("_", "!_");
        return "%" + escapado + "%";
    }
}
