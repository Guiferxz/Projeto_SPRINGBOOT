package br.com.ado.repository;

import br.com.ado.model.Tarefa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface TarefaRepository extends JpaRepository<Tarefa, Long> {

    long countByConcluida(boolean concluida);

    long countByData(LocalDate data);

    /**
     * Mesma lógica da view lista_tarefas do Django:
     * filtro (todas / concluidas / pendentes / alta) + pesquisa por título (sem
     * diferenciar maiúsculas) e ordenação por concluída, prioridade (Alta, Média,
     * Baixa) e data.
     *
     * @param padrao padrão LIKE já montado, com '!' como caractere de escape
     */
    @Query("""
            SELECT t FROM Tarefa t
            WHERE LOWER(t.titulo) LIKE :padrao ESCAPE '!'
              AND (:filtro = 'todas'
                   OR (:filtro = 'concluidas' AND t.concluida = true)
                   OR (:filtro = 'pendentes' AND t.concluida = false)
                   OR (:filtro = 'alta' AND t.prioridade = br.com.ado.model.Prioridade.ALTA))
            ORDER BY t.concluida ASC,
                     CASE t.prioridade
                         WHEN br.com.ado.model.Prioridade.ALTA THEN 0
                         WHEN br.com.ado.model.Prioridade.MEDIA THEN 1
                         ELSE 2
                     END ASC,
                     t.data ASC
            """)
    List<Tarefa> buscar(@Param("filtro") String filtro, @Param("padrao") String padrao);
}
