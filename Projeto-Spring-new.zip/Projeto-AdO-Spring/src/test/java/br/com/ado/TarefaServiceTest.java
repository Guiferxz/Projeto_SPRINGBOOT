package br.com.ado;

import br.com.ado.model.Prioridade;
import br.com.ado.model.Tarefa;
import br.com.ado.repository.TarefaRepository;
import br.com.ado.service.ResumoTarefas;
import br.com.ado.service.TarefaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(properties = "spring.datasource.url=jdbc:h2:mem:ado-service")
class TarefaServiceTest {

    @Autowired
    private TarefaService service;

    @Autowired
    private TarefaRepository repository;

    @BeforeEach
    void limparBanco() {
        repository.deleteAll();
    }

    @Test
    void deveOrdenarPorConclusaoPrioridadeEData() {
        salvar("A", false, LocalDate.of(2026, 11, 20), Prioridade.ALTA);
        salvar("B", false, LocalDate.of(2026, 11, 10), Prioridade.ALTA);
        salvar("C", false, LocalDate.of(2026, 11, 1), Prioridade.MEDIA);
        salvar("D", false, LocalDate.of(2026, 11, 1), Prioridade.BAIXA);
        salvar("E", true, LocalDate.of(2026, 11, 1), Prioridade.ALTA);

        assertThat(titulos(service.listar("", ""))).containsExactly("B", "A", "C", "D", "E");
    }

    @Test
    void deveFiltrarPorStatusEPrioridade() {
        salvar("A", false, LocalDate.of(2026, 11, 20), Prioridade.ALTA);
        salvar("B", false, LocalDate.of(2026, 11, 10), Prioridade.BAIXA);
        salvar("C", true, LocalDate.of(2026, 11, 1), Prioridade.ALTA);

        assertThat(titulos(service.listar("pendentes", ""))).containsExactly("A", "B");
        assertThat(titulos(service.listar("concluidas", ""))).containsExactly("C");
        assertThat(titulos(service.listar("alta", ""))).containsExactly("A", "C");
        assertThat(titulos(service.listar("qualquer-coisa", ""))).hasSize(3);
    }

    @Test
    void devePesquisarPorTituloSemDiferenciarMaiusculas() {
        salvar("Pagar conta de luz", false, LocalDate.of(2026, 11, 10), Prioridade.MEDIA);
        salvar("Estudar Spring", false, LocalDate.of(2026, 11, 10), Prioridade.MEDIA);

        assertThat(titulos(service.listar("", "LUZ"))).containsExactly("Pagar conta de luz");
        assertThat(titulos(service.listar("pendentes", "spring"))).containsExactly("Estudar Spring");
    }

    @Test
    void deveTratarCoringasDaPesquisaComoTextoLiteral() {
        salvar("Meta 100% concluída", false, LocalDate.of(2026, 11, 10), Prioridade.MEDIA);
        salvar("Meta 1000", false, LocalDate.of(2026, 11, 10), Prioridade.MEDIA);

        assertThat(titulos(service.listar("", "100%"))).containsExactly("Meta 100% concluída");
    }

    @Test
    void deveCalcularOResumo() {
        LocalDate hoje = LocalDate.now(ZoneId.of("America/Sao_Paulo"));
        salvar("Hoje pendente", false, hoje, Prioridade.ALTA);
        salvar("Hoje concluída", true, hoje, Prioridade.MEDIA);
        salvar("Outro dia", false, hoje.plusDays(5), Prioridade.BAIXA);

        ResumoTarefas resumo = service.resumo();

        assertThat(resumo.total()).isEqualTo(3);
        assertThat(resumo.hoje()).isEqualTo(2);
        assertThat(resumo.concluidas()).isEqualTo(1);
        assertThat(resumo.pendentes()).isEqualTo(2);
    }

    private void salvar(String titulo, boolean concluida, LocalDate data, Prioridade prioridade) {
        Tarefa t = new Tarefa();
        t.setTitulo(titulo);
        t.setConcluida(concluida);
        t.setData(data);
        t.setPrioridade(prioridade);
        repository.save(t);
    }

    private static List<String> titulos(List<Tarefa> tarefas) {
        return tarefas.stream().map(Tarefa::getTitulo).toList();
    }
}
