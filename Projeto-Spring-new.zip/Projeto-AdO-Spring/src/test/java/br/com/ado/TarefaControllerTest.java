package br.com.ado;

import br.com.ado.model.Prioridade;
import br.com.ado.model.Tarefa;
import br.com.ado.repository.TarefaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@SpringBootTest(properties = "spring.datasource.url=jdbc:h2:mem:ado-controller")
class TarefaControllerTest {

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private TarefaRepository repository;

    private MockMvc mockMvc;

    @BeforeEach
    void preparar() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
        repository.deleteAll();
    }

    @Test
    void deveExibirALista() throws Exception {
        salvar("Pagar conta de luz");

        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("tarefas/lista"))
                .andExpect(content().string(containsString("Pagar conta de luz")))
                .andExpect(content().string(containsString("Assistente de Organização")));
    }

    @Test
    void deveCriarTarefaValida() throws Exception {
        mockMvc.perform(post("/")
                        .param("titulo", "Estudar Spring")
                        .param("data", "2026-11-10")
                        .param("prioridade", "ALTA"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/"));

        assertThat(repository.count()).isEqualTo(1);
        Tarefa t = repository.findAll().get(0);
        assertThat(t.getTitulo()).isEqualTo("Estudar Spring");
        assertThat(t.getData()).isEqualTo(LocalDate.of(2026, 11, 10));
        assertThat(t.getPrioridade()).isEqualTo(Prioridade.ALTA);
        assertThat(t.isConcluida()).isFalse();
    }

    @Test
    void naoDeveCriarTarefaSemTitulo() throws Exception {
        mockMvc.perform(post("/")
                        .param("titulo", "   ")
                        .param("data", "2026-11-10")
                        .param("prioridade", "MEDIA"))
                .andExpect(status().isOk())
                .andExpect(view().name("tarefas/lista"))
                .andExpect(model().attributeHasFieldErrors("tarefaForm", "titulo"));

        assertThat(repository.count()).isZero();
    }

    @Test
    void naoDeveCriarTarefaComDataInvalida() throws Exception {
        mockMvc.perform(post("/")
                        .param("titulo", "Tarefa")
                        .param("data", "abc")
                        .param("prioridade", "MEDIA"))
                .andExpect(status().isOk())
                .andExpect(view().name("tarefas/lista"))
                .andExpect(model().attributeHasFieldErrors("tarefaForm", "data"));

        assertThat(repository.count()).isZero();
    }

    @Test
    void deveAlternarConclusao() throws Exception {
        Long id = salvar("Tarefa").getId();

        mockMvc.perform(post("/concluir/{id}", id))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/"));
        assertThat(repository.findById(id).orElseThrow().isConcluida()).isTrue();

        mockMvc.perform(post("/concluir/{id}", id));
        assertThat(repository.findById(id).orElseThrow().isConcluida()).isFalse();
    }

    @Test
    void deveExibirEEditarTarefa() throws Exception {
        Long id = salvar("Título antigo").getId();

        mockMvc.perform(get("/editar/{id}", id))
                .andExpect(status().isOk())
                .andExpect(view().name("tarefas/editar"))
                .andExpect(content().string(containsString("Título antigo")));

        mockMvc.perform(post("/editar/{id}", id)
                        .param("titulo", "Título novo")
                        .param("data", "2026-12-01")
                        .param("prioridade", "BAIXA"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/"));

        Tarefa t = repository.findById(id).orElseThrow();
        assertThat(t.getTitulo()).isEqualTo("Título novo");
        assertThat(t.getData()).isEqualTo(LocalDate.of(2026, 12, 1));
        assertThat(t.getPrioridade()).isEqualTo(Prioridade.BAIXA);
    }

    @Test
    void deveExcluirTarefa() throws Exception {
        Long id = salvar("Tarefa").getId();

        mockMvc.perform(post("/deletar/{id}", id))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/"));

        assertThat(repository.existsById(id)).isFalse();
    }

    @Test
    void deveResponder404ParaTarefaInexistente() throws Exception {
        mockMvc.perform(post("/concluir/{id}", 999999)).andExpect(status().isNotFound());
        mockMvc.perform(post("/deletar/{id}", 999999)).andExpect(status().isNotFound());
        mockMvc.perform(get("/editar/{id}", 999999)).andExpect(status().isNotFound());
    }

    private Tarefa salvar(String titulo) {
        Tarefa t = new Tarefa();
        t.setTitulo(titulo);
        t.setData(LocalDate.of(2026, 11, 10));
        t.setPrioridade(Prioridade.MEDIA);
        return repository.save(t);
    }
}
