# Assistente de Organização (Spring Boot)

Porte do projeto Django **Projeto-AdO** para **Spring Boot 4.1** (Java 21): gerenciador de tarefas
com painel de números, filtro, pesquisa, prioridades e ordenação automática.

## Como rodar

Requisitos: **JDK 21+** e **Maven 3.9+**.

```bash
mvn spring-boot:run
```

Abra http://localhost:8080. O banco (H2 em arquivo) é criado sozinho em `./data/`.

Outros comandos:

```bash
mvn test              # roda os testes
mvn clean package     # gera target/assistente-organizacao-1.0.0.jar
java -jar target/assistente-organizacao-1.0.0.jar
```

## Equivalência Django → Spring

| Django                                  | Spring Boot                                              |
|-----------------------------------------|----------------------------------------------------------|
| `tarefas/models.py` (`Tarefa`)          | `model/Tarefa.java` + `model/Prioridade.java` (enum)     |
| ORM / `Tarefa.objects...`               | `repository/TarefaRepository.java` (Spring Data JPA)     |
| `tarefas/views.py`                      | `controller/TarefaController.java` + `service/TarefaService.java` |
| `request.POST.get(...)`                 | `dto/TarefaForm.java` (com Bean Validation)              |
| `tarefas/urls.py`                       | anotações `@GetMapping` / `@PostMapping` no controller   |
| `templates/tarefas/*.html`              | `resources/templates/tarefas/*.html` (Thymeleaf)         |
| `static/css/style.css`                  | `resources/static/css/style.css`                         |
| `get_object_or_404`                     | `TarefaNaoEncontradaException` (HTTP 404)                |
| `settings.py`                           | `application.properties`                                 |
| `migrations/` + `migrate`               | `spring.jpa.hibernate.ddl-auto=update`                   |

## O que mudou de propósito

- **Concluir e Excluir agora são POST** (botões em formulário). No Django eram links GET, o que
  permite apagar tarefas só por um link/prefetch.
- **Validação**: título obrigatório (máx. 100), data válida e prioridade; os erros aparecem no formulário.
- **Tela de edição** agora já vem com a prioridade atual selecionada (antes voltava sempre para "Alta").
- O botão "Concluir" vira **"Reabrir"** quando a tarefa já está concluída (a ação sempre foi um toggle).
- A data é exibida como `dd/MM/yyyy`.
- A pesquisa trata `%` e `_` como texto comum.
- O banco é **H2** (em arquivo) no lugar do SQLite, pois o Hibernate não tem suporte oficial a SQLite.
  Os dados do `db.sqlite3` antigo não são migrados. Para usar PostgreSQL/MySQL, troque o driver no
  `pom.xml` e as propriedades `spring.datasource.*`.
- O Django Admin (`admin.py` estava vazio) não tem equivalente.

## Estrutura

```
src/main/java/br/com/ado/
├── AssistenteOrganizacaoApplication.java
├── controller/TarefaController.java
├── service/{TarefaService, ResumoTarefas}.java
├── repository/TarefaRepository.java
├── model/{Tarefa, Prioridade}.java
├── dto/TarefaForm.java
└── exception/TarefaNaoEncontradaException.java
src/main/resources/
├── application.properties
├── messages.properties
├── templates/tarefas/{lista, editar}.html
└── static/css/style.css
src/test/java/br/com/ado/        # testes do controller e do service
```
